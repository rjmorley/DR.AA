//
//  DrinksTableViewCell.swift
//  DR.AA
//
//  Created by rj morley on 11/30/17.
//  Copyright © 2017 ___rickjames___. All rights reserved.
//

import UIKit

class DrinksTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

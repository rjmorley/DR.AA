//
//  ViewController.swift
//  DR.AA
//
//  Created by rj morley on 11/6/17.
//  Copyright © 2017 ___rickjames___. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

var currentIndex = 0
var drinkToSearch = "ginDrinks"
//var Drinks: [String] = [String]()
//var RecipeArray: [String] = [String]()
var GlobalDrinkName: [String] = [String]()
var GlobalRecipes: [String] = [String]()

var savedDrinkNames: [String] = [String]()
var savedRecipes: [String] = [String]()


class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource {
    
    var ref: DatabaseReference!
    var handle : DatabaseHandle!
    
    var Drinks: [String] = [String]()
    var RecipeArray: [String] = [String]()
    
    
    
    

    @IBOutlet weak var AlcoholPicker: UIPickerView!
    @IBOutlet weak var DrinkTableview: UITableView!
   
    var Alcohols: [String] = [String]()
    
    @IBOutlet weak var MixerPicker: UIPickerView!
    
    
    @IBAction func goto2nd(_ sender: Any) {
    }
    
  
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Drinks.count
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "MainToRecipe", sender: self)
        currentIndex = indexPath.row
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = Drinks[indexPath.row]
        return cell
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Alcohols[row]
    }
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Alcohols.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        var tmpsrch = Alcohols[row]
        tmpsrch += "Drinks"
        print(tmpsrch)
        drinkToSearch = tmpsrch
        updateTable()
    }
    
   /*
  
    func postDrink() {
        let name = "Washington apple"
        let drinkName = "2oz of sour apple pucker, 2oz of whiskey and 2oz of cranberry juice!"
        let post : [String : AnyObject] = ["name" : name as AnyObject, "recipe" : drinkName as AnyObject]
        let tmpref = Database.database().reference()
        
        tmpref.child("whiskyDrinks").childByAutoId().setValue(post)
        
    }
    
 */
 
    func updateTable() {
        Drinks.removeAll()
        RecipeArray.removeAll()
        GlobalRecipes.removeAll()
        GlobalDrinkName.removeAll()
        print("Global names below")
        print(GlobalDrinkName)
        print(GlobalRecipes)
        ref = Database.database().reference().child(drinkToSearch)
        
        
        
        ref.observeSingleEvent(of: .value, with: { (DataSnapshot) in
            
            //print(DataSnapshot)
            if (DataSnapshot.value is NSNull){
                print("error")
            }
            else {
                
                for user_child in (DataSnapshot.children) {
                    let user_snap = user_child as! DataSnapshot
                    let dict = user_snap.value as! [String:String]
                    
                    let DrinksName = dict["name"]! as String
                    let DrinkRecipe = dict["recipe"]! as String
                    print(DrinksName)
                    print(DrinkRecipe)
                    self.Drinks.append(DrinksName)
                    self.RecipeArray.append(DrinkRecipe)
                }
            }
            print(self.Drinks)
            //print(self.RecipeArray)
            self.DrinkTableview.reloadData()
            GlobalDrinkName = self.Drinks
            GlobalRecipes = self.RecipeArray
            print("val for globals below")
            print(GlobalRecipes)
            print(GlobalDrinkName)
            
            

    }
        )}
    
    var DrinkArray = [[String:AnyObject]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //postDrink()
        // add recipe info down here too
        ref = Database.database().reference().child("vodkaDrinks")
        
        
        
        ref.observeSingleEvent(of: .value, with: { (DataSnapshot) in
            
            print(DataSnapshot)
            if (DataSnapshot.value is NSNull){
                print("error")
            }
            else {
                for user_child in (DataSnapshot.children) {
                    let user_snap = user_child as! DataSnapshot
                    let dict = user_snap.value as! [String:String]
                    
                    let DrinksName = dict["name"]! as String
                    let DrinkRecipe = dict["recipe"]! as String
                    print(DrinksName)
                    self.Drinks.append(DrinksName)
                    self.RecipeArray.append(DrinkRecipe)
                    print(self.RecipeArray)
                }
                GlobalDrinkName = self.Drinks
                GlobalRecipes = self.RecipeArray

            }
            //print(self.Drinks)
            print(GlobalDrinkName)
            self.DrinkTableview.reloadData()
            
            /*let val = DataSnapshot.childSnapshot(forPath: "name") as? String
            
            print(val)
            var newdrinks = [DataSnapshot]
            
            for child in DataSnapshot.children{
                let snap = child as! DataSnapshot
                let DrinkName = snap.value
                print(DrinkName)
            }
            //self.Drinks = newdrinks
            
            //print(self.Drinks)
            */
           /* if let actualVal = val {
                self.Drinks.append(actualVal)
                print(self.Drinks)
                self.DrinkTableview.reloadData()
            }*/
        
        })
        
        
        self.AlcoholPicker.delegate = self
        self.AlcoholPicker.dataSource = self
        
        
        Alcohols = ["vodka", "gin", "rum", "tequila", "whisky"]
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


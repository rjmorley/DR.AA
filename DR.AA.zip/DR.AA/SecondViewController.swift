//
//  SecondViewController.swift
//  DR.AA
//
//  Created by rj morley on 11/6/17.
//  Copyright © 2017 ___rickjames___. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var NameLabel: UILabel!
    
    @IBOutlet weak var RecipeLabel: UILabel!
    @IBOutlet weak var AddFavButton: UIButton!
    // this is the view controller accessed when one clicks on the table view from the first view controller this will display the recipe for the drink the user can then click the heart button to add the drink to their favorites page which will be saved locally so they can be accessed with out internet connection

    
    
    @IBAction func AddFav(_ sender: Any) {
        //print(GlobalDrinkName)
        //print(GlobalDrinkName[currentIndex])
        let FavObj = UserDefaults.standard.object(forKey: "Favorite")
        
        
        
        var TmpFavName = GlobalDrinkName[currentIndex]
        var TmpFavRecipe = GlobalRecipes[currentIndex]
        print(TmpFavName)
        
        var favName: [String]
        var favRecipe: [String]
        // check if let statement and adjust var names so its consistent with othr naems and saves properly
        if var tmpFaves = FavObj as? [String] {
            print("in if let")
            
            favName = tmpFaves
            favName.append(TmpFavName)
            
            print(favName)
        }
        else {
            favName = [TmpFavName]
            print("error")
        }
        UserDefaults.standard.set(favName, forKey: "Favorite")
        
        let RecipeObject = UserDefaults.standard.object(forKey: "FavRecipe")
        if var tmpRecipe = RecipeObject as? [String] {
            favRecipe = tmpRecipe
            favRecipe.append(TmpFavRecipe)
        }
        else {
            favRecipe = [TmpFavRecipe]
        }
        UserDefaults.standard.set(favRecipe, forKey: "FavRecipe")
        
    }
   
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      /*  print("second vc")
        if GlobalRecipes != nil {
            print(GlobalRecipes[currentIndex])
            RecipeLabel.text = GlobalRecipes[currentIndex]
        }
        if GlobalDrinkName != nil {
            print(GlobalDrinkName[currentIndex])
            var NameLabeltext = GlobalDrinkName[currentIndex]
            NameLabel?.text = NameLabeltext
        }
        else{
            print("error retrieving name")
        }
        
                */
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        print("second vc")
        
        if GlobalRecipes != nil {
            print(GlobalRecipes[currentIndex])
            RecipeLabel.text = GlobalRecipes[currentIndex]
        }
        if GlobalDrinkName != nil {
            print(GlobalDrinkName[currentIndex])
            var NameLabeltext = GlobalDrinkName[currentIndex]
            NameLabel?.text = NameLabeltext
        }
        else{
            print("error retrieving name")
        }

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

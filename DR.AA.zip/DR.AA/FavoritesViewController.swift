//
//  FavoritesViewController.swift
//  DR.AA
//
//  Created by rj morley on 12/3/17.
//  Copyright © 2017 ___rickjames___. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

var GlobalFaves: [String] = [String]()
var favIndex = 0

class FavoritesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableOutlet: UITableView!
    
    var favName: [String] = []
    var faveRecipes: [String] = []
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return favName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        cell.textLabel?.text = favName[indexPath.row] as! String
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == UITableViewCellEditingStyle.delete {
            favName.remove(at: indexPath.row)
            tableOutlet.reloadData()
            
            faveRecipes.remove(at: indexPath.row)
            
            UserDefaults.standard.set(favName, forKey: "Favorite")
            UserDefaults.standard.set(faveRecipes, forKey: "FavRecipe")
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        favIndex = indexPath.row
        performSegue(withIdentifier: "FavTableToRecipe", sender: self)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let FavObject = UserDefaults.standard.object(forKey: "Favorite")
        
        if let tmpFavs = FavObject as? [String] {
            favName = tmpFavs
            print(favName)
        }
        
        
        let RecipeObject = UserDefaults.standard.object(forKey: "FavRecipe")
        
        if let tempFavRecipe = RecipeObject as? [String] {
            faveRecipes = tempFavRecipe
            
        }
        GlobalFaves = faveRecipes
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
